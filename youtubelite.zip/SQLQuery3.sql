--create database youtuber

create table youtubeuser (id int, fullname varchar(100), email varchar(50))

create table youtubepost (id int, username varchar(20), videolink varchar(50),countryvideoisuploaded varchar(50), currency varchar(50), logindate date, logintime time)

create table country (countryid varchar(50), countryname varchar(50), countryregion varchar(50))

create table videouploaded(videoname varchar(100), videosize int, uploadername varchar(50), videolength int)

insert into youtubeuser (id, fullname, email)
values (100, 'James Morgan', 'morganjay@gmail.com')

SELECT * FROM youtubeuser
